package org.renpy.android;

public class Constants {
	// Used by the google play store.
    public static String PLAY_BASE64_PUBLIC_KEY = "{{ config.google_play_key }}";
    public static byte[] PLAY_SALT = new byte[] { {{ config.google_play_salt }} };

    // Used by the expansion downloader.
    public static int fileVersion = {{ config.numeric_version }};
    public static int fileSize = {{ file_size }};

    // Used by the in-app purchasing code.
    public static String store = "{{ config.store }}";
}
