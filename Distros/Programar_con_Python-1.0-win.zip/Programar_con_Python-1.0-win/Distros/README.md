#Instrucciones
###Baje y descomprima el archivo *Programar_con_Python-1.0-all.zip* en algun sitio de su computadora
#Windows
###Ejecute el archivo *Programar_con_Python.exe* dentro de la carpeta *Programar_con_Python-1.0-all*
#MacOS and Linux
###Ejecute el archivo *Programar_con_Python.sh* dentro de la carpeta *Programar_con_Python-1.0-all*
#Android
###Baje el programa de su página en el [Google Store!](https://play.google.com/store/apps/details?id=com.hedleypanama)
 
#Advertencia

Este programa está incompleto, vea el README.md en el directorio raíz donde indico el avance del proyecto

